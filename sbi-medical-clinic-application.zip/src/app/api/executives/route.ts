import { NextResponse } from "next/server";
import { db } from "@/db";
import { branches, executives } from "@/db/schema";

export const dynamic = "force-dynamic";

/** GET /api/executives — SBI leadership roster plus network size. */
export async function GET() {
  const rows = await db.select().from(executives).orderBy(executives.sortOrder);
  const allBranches = await db.select({ slug: branches.slug }).from(branches);
  return NextResponse.json({
    count: rows.length,
    executives: rows,
    publishedBranches: allBranches.length,
  });
}
