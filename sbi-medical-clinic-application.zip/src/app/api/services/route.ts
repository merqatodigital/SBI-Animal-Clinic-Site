import { NextResponse } from "next/server";
import { db } from "@/db";
import { services } from "@/db/schema";

export const dynamic = "force-dynamic";

/** GET /api/services — full SKU list (active vaccines, immunoglobulins, tetanus biologics). */
export async function GET() {
  const rows = await db.select().from(services).orderBy(services.sortOrder);
  return NextResponse.json({ count: rows.length, services: rows });
}
