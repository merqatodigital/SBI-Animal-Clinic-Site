import { NextRequest, NextResponse } from "next/server";
import { and, eq, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { branches } from "@/db/schema";

export const dynamic = "force-dynamic";

/**
 * GET /api/branches?region=Luzon&city=Antipolo%20City&q=marikina
 * SBI branch directory. All filters are optional and combinable.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const region = searchParams.get("region");
  const city = searchParams.get("city");
  const q = searchParams.get("q");

  const filters = [];
  if (region) filters.push(eq(branches.region, region));
  if (city) filters.push(eq(branches.city, city));
  if (q) {
    const pattern = `%${q.trim()}%`;
    filters.push(
      or(
        sql`${branches.name} ILIKE ${pattern}`,
        sql`${branches.address} ILIKE ${pattern}`,
        sql`${branches.city} ILIKE ${pattern}`,
        sql`${branches.province} ILIKE ${pattern}`,
        sql`${branches.contact} ILIKE ${pattern}`,
      )!,
    );
  }

  const rows = await db
    .select()
    .from(branches)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(branches.region, branches.name);

  return NextResponse.json({ count: rows.length, branches: rows });
}
