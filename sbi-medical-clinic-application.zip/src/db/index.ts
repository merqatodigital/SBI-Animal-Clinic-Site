// ─────────────────────────────────────────────────────────────────────────────
// SBI database client — Neon-ready Postgres code tree
// ─────────────────────────────────────────────────────────────────────────────
// Works unchanged against:
//   • Local Postgres  (DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db)
//   • Neon (https://neon.com) — pooled or direct, IPv4 or SNI-routed.
//
// Neon setup (2 minutes):
//   1. Create a project at https://console.neon.tech → copy the connection string.
//      It looks like:
//        postgresql://<user>:<password>@<endpoint>.neon.tech/<dbname>?sslmode=require
//   2. Set it as DATABASE_URL in your hosting env (Vercel → Project → Settings →
//      Environment Variables). For local dev, put it in `.env`.
//   3. Run `npx drizzle-kit push` once to create all tables (branches, bookings,
//      site_settings, content_sections, faqs, social_links, media_assets).
//   4. Run `npx tsx scripts/seed.ts` + `npx tsx scripts/seed-cms.ts` to populate.
// See NEON_SETUP.md at the project root for branching, pooling and Vercel notes.
//
// Implementation note: plain `pg` Pool works against Neon (it is wire-compatible
// Postgres). SSL is forced on for any *.neon.tech host so serverless deploys do
// not fail on certificate negotiation.
// ─────────────────────────────────────────────────────────────────────────────
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

const isNeon = databaseUrl.includes("neon.tech");

const globalForDb = globalThis as typeof globalThis & {
  __sbiPool?: Pool;
};

export const pool =
  globalForDb.__sbiPool ??
  new Pool({
    connectionString: databaseUrl,
    // Neon requires TLS. Local Postgres does not.
    ...(isNeon ? { ssl: { rejectUnauthorized: false } } : {}),
    max: isNeon ? 10 : 20,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__sbiPool = pool;
}

pool.on("error", (err) => {
  console.error("[db] idle pool error", err);
});

export const db = drizzle(pool);
export const isNeonBackend = isNeon;
